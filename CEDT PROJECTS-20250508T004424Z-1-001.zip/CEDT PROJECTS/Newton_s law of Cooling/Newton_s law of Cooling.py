import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Load data from CSV
data = np.loadtxt('nw.csv', delimiter=',', skiprows=1)
time = data[:, 0]  # Assuming time is in the first column
temperature = data[:, 2]  # Assuming temperature is in the second column
T0_values = data[:, 1]  # Assuming T0 values are in the third column

# Define the Newton's Law of Cooling function with T0 and k as parameters
def newtons_law_of_cooling(t, T0, k):
    return T0 + (temperature[0] - T0) * np.exp(-k * t)

# Fit the curve to the data
popt, pcov = curve_fit(newtons_law_of_cooling, time, temperature, p0=[T0_values[0], 0.0035233635])

# Extract the fitted parameters
T0_fit, k_fit = popt

# Plot the original data
plt.scatter(time, temperature, label='Original Data',linestyle='-')

# Plot the fitted curve
plt.plot(time, newtons_law_of_cooling(time, T0_fit, k_fit), 'r-', label='Fitted Curve')

# Add labels and legend
plt.plot(time,temperature, color='blue', linestyle='-', label='Obtained Curve')
plt.xlabel('Time(Minutes)')
plt.ylabel('Temperature(°C)')
plt.title("Newton's Law of Cooling")
plt.legend()

# Show plot
plt.grid(True)
plt.show()

print("Estimated T0:", T0_fit)
print("Estimated k:", k_fit)