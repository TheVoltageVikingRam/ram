import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Load data from CSV file, skipping the first row
data = np.loadtxt('D1.csv', delimiter=',', skiprows=1)  # adjust the filename

voltage = data[:, 0]
current = data[:, 1]

# Plot the original data and the fitting curve
plt.scatter(voltage,current, label='Data Points',color='red')
plt.plot(voltage, current, color='blue', linestyle='-', label='Obtained Curve')
plt.xlabel('Voltage across the Diode in Volts')
plt.ylabel('Current Through Diode in uA')
plt.legend()
plt.title('1N4007 Diode I-V Characteristic Curve')
plt.grid(True)
plt.show()
