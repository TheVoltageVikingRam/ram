import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Load data from CSV file, skipping the first 3 rows
data = np.loadtxt('D1.csv', delimiter=',', skiprows=3)  # adjust the filename and skiprows parameter

# Separate x (voltage) and y (current) data
voltage = data[:, 0]
current = data[:, 1]

# Take the natural logarithm of the current
ln_current = np.log(current)

# Define the fitting function (Shockley diode equation)
def diode_iv_curve_ln(v, Is, n, Vt):
    return np.log(Is) + (v / (n * Vt))

# Initial guess for the parameters
initial_guess = [1e-6, 1.5, 0.02585]  # Adjusted initial guess values for 1N4007 diode

# Perform the curve fitting
popt, pcov = curve_fit(diode_iv_curve_ln, voltage, ln_current, p0=initial_guess)

# Generate y values using the fitted function
ln_current_fit = diode_iv_curve_ln(voltage, *popt)

# Plot the original data and the fitting curve with connected points
plt.scatter(voltage, ln_current, label='Data Points')
plt.plot(voltage, ln_current_fit, color='red', label='Fitting Curve')

# Connect original data points
plt.plot(voltage, ln_current, color='blue', linestyle='-', label='Obtained Curve')

plt.xlabel('Voltage across the diode in Volts')
plt.ylabel('ln(Current through the Diode in uA)')
plt.legend()
plt.title('1N4007 Diode I-V Characteristic Curve')
plt.grid(True)
plt.show()

# Print the fitted parameters
print("Fitted parameters (Is, n, Vt):", popt)
